//
//  MusicAlbumViewModel.swift
//  SampleApp
//
//  Created by Himanshu on 26/07/22.
//

import Foundation
class MusicAlbumViewModel:BaseAPI{
    //MARK: - variables
    var model:MusicAlbum?
    //MARK: - func
    func musicAlbumApi(compilation:@escaping(Bool,String)->()){
        let request = Request(url: (URLS.baseUrl,APISuffix.songList), method: .get, parameters: nil, headers: false)
        super.hitApi(requests: request){
           (receievedData,message,responseCode) in
            if responseCode == 1{
                if let data = receievedData as? [String:Any] {
                            do{
                                let jsonSer = try JSONSerialization.data(withJSONObject: data, options:.prettyPrinted)
                                self.model = try JSONDecoder().decode(MusicAlbum.self, from: jsonSer)
                                compilation(true,message ?? "")
                            }
                            catch{
                                print(error)
                                compilation(false,message ?? "")
                            }
                        }
                        else{
                            compilation(false,message ?? "")
                        }
                    }
                    else{
                        compilation(false,message ?? "")
                    }
            }
    }
}
