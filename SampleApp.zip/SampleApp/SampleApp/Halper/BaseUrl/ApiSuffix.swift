//
//  ApiSuffix.swift
//  testApp
//
//  Created by mac on 04/03/22.
//

import Foundation
enum APISuffix {
    case songList
    func getDescription() -> String {
        switch self{
        case .songList :
            return "100/albums.json"
        }
    }
}
enum URLS {
    case baseUrl
    func getDescription() -> String {
    switch self {
    case .baseUrl :
        return "https://rss.applemarketingtools.com/api/v2/us/music/most-played/"
    }
    }
}
