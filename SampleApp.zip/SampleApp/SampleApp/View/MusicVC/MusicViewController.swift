//
//  MusicViewController.swift
//  SampleApp
//
//  Created by Himanshu on 25/07/22.
//

import UIKit
import SDWebImage

class MusicViewController: UIViewController{
    //MARK: - variables
    private let music_CV: UICollectionView = {
        let viewLayout = UICollectionViewFlowLayout()
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: viewLayout)
        collectionView.backgroundColor = .white
        return collectionView
    }()
    
    var viewModel = MusicAlbumViewModel()
    
    //MARK: - LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Top 100 Albums"
        setupViews()
        setupLayouts()
        ApiCall()
    }
    //MARK: - IBAction
    //MARK: -  func
    private func setupLayouts() {
        music_CV.translatesAutoresizingMaskIntoConstraints = false
        // Layout constraints for `collectionView`
        NSLayoutConstraint.activate([
            music_CV.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 16),
            music_CV.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant:-16),
            music_CV.topAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.topAnchor,constant:16),
            music_CV.bottomAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.bottomAnchor,constant:-16)
        ])
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        view.addSubview(music_CV)
        music_CV.dataSource = self
        music_CV.delegate = self
        music_CV.register(MusicCell.self, forCellWithReuseIdentifier:MusicCell.identifier)
    }
    
    func ApiCall(){
        viewModel.musicAlbumApi { isSuccess, message in
            if isSuccess{
                self.music_CV.reloadData()
            }else{
                let alert = UIAlertController(title: " ", message: message, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}
//MARK: - collectionView DataSource
extension MusicViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.model?.feed.results.count ?? 0    }

    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = music_CV.dequeueReusableCell(withReuseIdentifier: "MusicCell", for: indexPath) as! MusicCell
        cell.ImageView.layer.cornerRadius = 12
        cell.ImageView.sd_setImage(with: URL(string: (viewModel.model?.feed.results[indexPath.row].artworkUrl100 ?? " ")))
        cell.albumName.text = viewModel.model?.feed.results[indexPath.row].name as? String
        cell.albumArtist.text = viewModel.model?.feed.results[indexPath.row].artistName as? String
        return cell
    }
    
}
//MARK: - CollectionViewDelegate
extension MusicViewController: UICollectionViewDelegate,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return(CGSize(width:(music_CV.frame.width-20)/2,height:(music_CV.frame.height-20)/4.5))
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Index:\(indexPath.row)")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "MusicDetailVC") as! MusicDetailViewController
        vc.imageView.sd_setImage(with: URL(string: (viewModel.model?.feed.results[indexPath.row].artworkUrl100 ?? " ")))
        vc.albumNa = viewModel.model?.feed.results[indexPath.row].name ?? " "
        vc.artistNA = viewModel.model?.feed.results[indexPath.row].artistName ?? " "
        vc.ReleaseDa = viewModel.model?.feed.results[indexPath.row].releaseDate ?? " "
        vc.copyrig = viewModel.model?.feed.copyright ?? " "
        vc.generes = (viewModel.model?.feed.results.first?.genres[00].url ?? " ")
        vc.GenFirstID = viewModel.model?.feed.results.first?.genres[00].genreID ?? " "
        vc.GenSecondURl = viewModel.model?.feed.results.first?.genres[01].url ?? " "
        navigationController?.pushViewController(vc, animated: true)
    }
}
