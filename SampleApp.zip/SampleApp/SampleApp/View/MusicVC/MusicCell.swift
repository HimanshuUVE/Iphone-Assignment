//
//  MusicCell.swift
//  SampleApp
//
//  Created by Himanshu on 25/07/22.
//

import UIKit
class MusicCell: UICollectionViewCell {
    //MARK: -
    static let identifier = "MusicCell"
    var MyView = UIView()
    var ImageView = UIImageView()
    var albumName = UILabel()
    var albumArtist = UILabel()
    
    //MARK: -
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.contentView.backgroundColor = .clear
        self.MyView.backgroundColor = .blue
        self.backgroundColor = .clear
        MyView.layer.cornerRadius = 25
        MyView.frame = contentView.frame
        addSubview(MyView)
        
        album()
        nameOFAlbum()
        artistOfAlbum()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    //MARK: - function
    func album(){
        ImageView.contentMode = .scaleToFill
        ImageView.layer.cornerRadius = 25
        ImageView.clipsToBounds = true
        MyView.addSubview(ImageView)
        ImageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            ImageView.leadingAnchor.constraint(equalTo:MyView.leadingAnchor, constant: -1),
            ImageView.trailingAnchor.constraint(equalTo:MyView.trailingAnchor,constant: 1),
            ImageView.topAnchor.constraint(equalTo:MyView.topAnchor,constant: -1),
            ImageView.bottomAnchor.constraint(equalTo:MyView.bottomAnchor,constant:1)
        ])
    }
    func nameOFAlbum(){
        albumName.numberOfLines = 0
        albumName.textAlignment = .left
        albumName.translatesAutoresizingMaskIntoConstraints = false
        albumName.font = .systemFont(ofSize:13, weight: .bold)
        albumName.textColor = .white
        MyView.addSubview(albumName)
        NSLayoutConstraint.activate([
            albumName.leadingAnchor.constraint(equalTo:ImageView.leadingAnchor,constant:10),
            albumName.trailingAnchor.constraint(equalTo: ImageView.trailingAnchor,constant:-10),
            albumName.topAnchor.constraint(lessThanOrEqualTo: ImageView.bottomAnchor,constant: -30)
        ])
    }
    func artistOfAlbum(){
        albumArtist.text = "Arijit singh"
        albumArtist.numberOfLines = 0
        albumArtist.font = .systemFont(ofSize: 14, weight: .light)
        albumArtist.textAlignment = .left
        albumArtist.textColor = .white
        albumArtist.translatesAutoresizingMaskIntoConstraints = false
        MyView.addSubview(albumArtist)
        NSLayoutConstraint.activate([
            albumArtist.leadingAnchor.constraint(equalTo:ImageView.leadingAnchor,constant:10),
            albumArtist.trailingAnchor.constraint(equalTo: ImageView.trailingAnchor,constant:-10),
            albumArtist.topAnchor.constraint(equalTo: albumName.bottomAnchor,constant: 5),
            albumArtist.bottomAnchor.constraint(equalTo:ImageView.bottomAnchor,constant: -5)
        ])
    }
}
