//
//  MusicDetailViewController.swift
//  SampleApp
//
//  Created by Himanshu on 25/07/22.
//
import UIKit
class MusicDetailViewController: UIViewController{
    //MARK: - variables
    var imageView = UIImageView()
    var albumNa:String = ""
    var artistNA:String = ""
    var ReleaseDa:String = ""
    var copyrig:String = ""
    var generes:String = ""
    var GenFirstID:String = ""
    var GenSecondURl:String = ""
    
    //MARK: - LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        NavigationItem()
        album()
    }
    //MARK: - IBAction
    //MARK: -  func
    func NavigationItem(){
        navigationItem.title = "Music Detail"
        let backButton = UIButton(frame: CGRect(x: 15, y: 15, width: 35, height: 35))
        backButton.setImage(UIImage(systemName: "arrow.backward"), for: UIControl.State.normal)
        backButton.tintColor = UIColor.black
        backButton.contentMode = .left
        backButton.addTarget(self, action: #selector(DidTapLeft(_ :)), for: .touchUpInside)
        let leftBarBtnItem:UIBarButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = leftBarBtnItem
    }
    func album(){
        imageView.contentMode = .scaleToFill
        imageView.layer.cornerRadius = 12
        imageView.clipsToBounds = true
        view.addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imageView.centerYAnchor.constraint(equalTo:view.centerYAnchor,constant:-170),
            imageView.centerXAnchor.constraint(equalTo:view.centerXAnchor),
            imageView.heightAnchor.constraint(equalToConstant: 270 ),
            imageView.widthAnchor.constraint(equalToConstant: 300 )
        ])
        let albumName = UILabel()
        albumName.text = "Album Name : - \(albumNa )"
        albumName.font = .systemFont(ofSize: 18, weight: .medium)
        albumName.numberOfLines = 0
        view.addSubview(albumName)
        albumName.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            albumName.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            albumName.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            albumName.topAnchor.constraint(equalTo:self.imageView.bottomAnchor,constant: 20)
        ])
        let artistNAme = UILabel()
        artistNAme.text = "Artist Name : - \(String(describing: artistNA ))"
        artistNAme.numberOfLines = 0
        artistNAme.font = .systemFont(ofSize: 18, weight: .medium)
        view.addSubview(artistNAme)
        artistNAme.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            artistNAme.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            artistNAme.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            artistNAme.topAnchor.constraint(equalTo:albumName.bottomAnchor,constant: 10)
        ])
        
        let ReleaseDate = UILabel()
        ReleaseDate.text = "Release Date : - \(String(describing: ReleaseDa ))"
        ReleaseDate.numberOfLines = 0
        ReleaseDate.font = .systemFont(ofSize: 18, weight: .medium)
        view.addSubview(ReleaseDate)
        ReleaseDate.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            ReleaseDate.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            ReleaseDate.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            ReleaseDate.topAnchor.constraint(equalTo:artistNAme.bottomAnchor,constant: 10)
        ])
        let GeneresUrl = UIButton()
        GeneresUrl.setTitle("GeneresUrl",for: UIControl.State.normal)
        GeneresUrl.backgroundColor = .gray
        GeneresUrl.addTarget(self, action: #selector(DidTapApple(_ :)), for:.touchUpInside)
        view.addSubview(GeneresUrl)
        GeneresUrl.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            GeneresUrl.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            GeneresUrl.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            GeneresUrl.topAnchor.constraint(equalTo:ReleaseDate.bottomAnchor,constant: 10),
            GeneresUrl.heightAnchor.constraint(equalToConstant:20)
        ])
        let GeneriesFirstID = UILabel ()
        GeneriesFirstID.text =  "ID : - \(GenFirstID)"
        GeneriesFirstID.font = .systemFont(ofSize:15, weight: .light)
        GeneriesFirstID.numberOfLines = 0
        view.addSubview(GeneriesFirstID)
        GeneriesFirstID.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            GeneriesFirstID.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            GeneriesFirstID.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            GeneriesFirstID.topAnchor.constraint(equalTo:GeneresUrl.bottomAnchor,constant: 10)
        ])
        let GeneriesFirstName = UILabel ()
        GeneriesFirstName.text = "Name: - Music"
        GeneriesFirstName.numberOfLines = 0
        GeneriesFirstName.font = .systemFont(ofSize:15, weight: .light)
        view.addSubview(GeneriesFirstName)
        GeneriesFirstName.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            GeneriesFirstName.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            GeneriesFirstName.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            GeneriesFirstName.topAnchor.constraint(equalTo:GeneriesFirstID.bottomAnchor,constant: 10)
        ])
        let GeneresSecondURl = UIButton()
        GeneresSecondURl.setTitle("GeneresSecondUrl",for: UIControl.State.normal)
        GeneresSecondURl.backgroundColor = .gray
        GeneresSecondURl.addTarget(self, action: #selector(DidTapSecondApple(_ :)), for:.touchUpInside)
        view.addSubview(GeneresSecondURl)
        GeneresSecondURl.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            GeneresSecondURl.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            GeneresSecondURl.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            GeneresSecondURl.topAnchor.constraint(equalTo:GeneriesFirstName.bottomAnchor,constant:10),
            GeneresSecondURl.heightAnchor.constraint(equalToConstant:20)
        ])
        let GeneresSecondName = UILabel()
        GeneresSecondName.text = "Generes Second Name : - Soundtrack"
        GeneresSecondName.numberOfLines = 0
        view.addSubview(GeneresSecondName)
        GeneresSecondName.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            GeneresSecondName.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 25),
            GeneresSecondName.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -25),
            GeneresSecondName.topAnchor.constraint(equalTo:GeneresSecondURl.bottomAnchor,constant:10)
        ])
        let copyright = UILabel ()
        copyright.text = copyrig
        copyright.font = .systemFont(ofSize:15, weight: .light)
        view.addSubview(copyright)
        copyright.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            copyright.leadingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.leadingAnchor,constant: 27),
            copyright.trailingAnchor.constraint(equalTo:self.view.safeAreaLayoutGuide.trailingAnchor,constant: -27),
            copyright.bottomAnchor.constraint(equalTo:view.safeAreaLayoutGuide.bottomAnchor,constant: 10)
        ])
        
    }
    
   //MARK: - OBjc func
    @objc func DidTapLeft( _ :UIButton){
        navigationController?.popViewController(animated: true)
    }
    @objc func DidTapApple( _ :UIButton){
        let url = URL(string: generes)
        UIApplication.shared.openURL(url!)
    }
    @objc func DidTapSecondApple( _ :UIButton){
        let url = URL(string: GenSecondURl)
        UIApplication.shared.openURL(url!)
    }
}
